<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="lunar1b_tileset_compact_grey" tilewidth="32" tileheight="32" tilecount="128" columns="16">
 <image source="../../lunar1b_tileset_compact_grey.png" width="512" height="256"/>
</tileset>
