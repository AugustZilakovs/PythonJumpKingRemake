<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="sunrise-parallax" tilewidth="32" tileheight="32" tilecount="7750" columns="125">
 <image source="sunrise-parallax.png" width="4000" height="2000"/>
</tileset>
